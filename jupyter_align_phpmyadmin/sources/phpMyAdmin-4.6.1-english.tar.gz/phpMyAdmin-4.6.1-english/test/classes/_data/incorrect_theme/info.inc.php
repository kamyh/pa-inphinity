<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Incorrect theme information file.
 * Full name is not specified
 *
 * @package PhpMyAdmin-test
 */

$theme_full_version = '1.0';
