import sys, time
for i in range(100):
  #x='\r%s' % i
  #print x,
  sys.stdout.write('\r%s' % i)
  sys.stdout.flush()
  time.sleep(0.1)
