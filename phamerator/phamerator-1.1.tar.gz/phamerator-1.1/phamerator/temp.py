import db_conf
c = db_conf.db_conf().get_cursor()

if 1==1:
  c.execute("SELECT GeneID FROM gene WHERE GeneID = 'BPs_gp57'")
  newGenes = []
  ng = c.fetchall()
  c.execute("SELECT GeneID FROM gene")
  oldGenes = []
  og = c.fetchall()
  for o in og: oldGenes.append(o[0])
  alignsToAdd = (len(og)*(len(og)-1))*2

  # add the genes by nested for loops, remembering to compare every new gene to every other new gene
  allGenes = oldGenes + newGenes
  cexec = c.execute
  for n in newGenes:
    for a in allGenes:
      if n == a: break
      else:
        if 1 == 1:
          # add a blast alignment
          #sqlQuery = """INSERT INTO blast () VALUES ()"""
          #cexec(sqlQuery)
          cexec("""INSERT INTO blast () VALUES ()""")
          # add a clustalw alignment
          #sqlQuery = """INSERT INTO clustalw (id) VALUES (LAST_INSERT_ID())"""
          #cexec(sqlQuery)
          cexec("""INSERT INTO clustalw (id) VALUES (LAST_INSERT_ID())""")
          # add an alignment where each new gene is a query for every other gene in the db
          #sqlQuery = """INSERT INTO alignment (GeneID, type, blast_id, clustalw_id) VALUES ('%s', 'Q', LAST_INSERT_ID(), LAST_INSERT_ID())""" % n
          #cexec(sqlQuery)
          cexec("""INSERT INTO alignment (GeneID, type, blast_id, clustalw_id) VALUES ('%s', 'Q', LAST_INSERT_ID(), LAST_INSERT_ID())""" % n)
          # each other gene is a subject
          #sqlQuery = """INSERT INTO alignment (GeneID, type, blast_id, clustalw_id) VALUES ('%s', 'S', LAST_INSERT_ID(), LAST_INSERT_ID())""" % a
          #cexec(sqlQuery)
          cexec("""INSERT INTO alignment (GeneID, type, blast_id, clustalw_id) VALUES ('%s', 'S', LAST_INSERT_ID(), LAST_INSERT_ID())""" % a)
          # add a blast (but not a clustalw) alignment for the reverse combination
          #sqlQuery = """INSERT INTO blast () VALUES ()"""
          #cexec(sqlQuery)
          cexec("""INSERT INTO blast () VALUES ()""")
          # add an alignment where each new gene is a subject for every other gene in the db
          #sqlQuery = """INSERT INTO alignment (GeneID, type, blast_id) VALUES ('%s', 'S', LAST_INSERT_ID())""" % n
          #cexec(sqlQuery)
          cexec("""INSERT INTO alignment (GeneID, type, blast_id) VALUES ('%s', 'S', LAST_INSERT_ID())""" % n)
          # each other gene is the query
          #sqlQuery = """INSERT INTO alignment (GeneID, type, blast_id) VALUES ('%s', 'Q', LAST_INSERT_ID())""" % a
          #cexec(sqlQuery)
          cexec("""INSERT INTO alignment (GeneID, type, blast_id) VALUES ('%s', 'Q', LAST_INSERT_ID())""" % a)
