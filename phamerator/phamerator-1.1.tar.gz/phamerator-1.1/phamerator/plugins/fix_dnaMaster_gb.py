#!/usr/bin/python

import sys

infile = open(sys.argv[1])
outfile = open(sys.argv[1]+'.fixed', 'w')

lines = infile.readlines()
locusline = lines.pop(0)

locusline = locusline.replace('.dnam5', '   ')
#LOCUS       bakaDRAFTcabx.dnam5   111688 bp    DNA     circular     13-FEB-2010
#LOCUS       angelica               50310 bp    DNA     linear       16-FEB-2010

try:
  locus, phage, length, bp, DNA, lin_or_circ, date = locusline.split()
except:
  locusline = locusline + lines.pop(0)
  locusline = locusline.replace('\n', '   ')

locus, phage, length, bp, DNA, lin_or_circ, date = locusline.split()
phage = phage[0:21]

newlocusline = locus + (' ' * 7)
newlocusline = newlocusline + phage + (' ' * (28-len(phage)-len(length)))
newlocusline = newlocusline + length
newlocusline = newlocusline + ' ' + bp + (' ' * 4)
newlocusline = newlocusline + DNA + (' ' * 5)
newlocusline = newlocusline + lin_or_circ + (' ' * (13-len(lin_or_circ)))
newlocusline = newlocusline + date

#print newlocusline
outfile.write(newlocusline)
outfile.write('\n')
#outfile.write(lines)

for line in lines:
  line = line.replace('\r\n', '')
  outfile.write(line)
  outfile.write('\n')
#  print line
