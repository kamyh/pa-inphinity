#!/usr/bin/env python

import urllib2, os, sys, threading

class dbStatus(threading.Thread):
  def __init__(self, username, password, server, database, evnt):
    threading.Thread.__init__(self)
    self.username = username
    self.password = password
    self.server = server
    self.db = database
    self.evnt = evnt
  def updateDB(self, user, password, server, db):
    home = os.environ['HOME']
    fname = '%s/.phamerator/%s.sql' % (home, db)
    #try:
    #  os.system('rsync -a %s::http/%s.sql %s' % (server, db, os.path.join(home, '.phamerator')))
    #  print 'using rsync to grab %s.sql' % db
    #  print 'rsync -a %s::http/%s.sql %s' % (server, db, os.path.join(home, '.phamerator'))
    #except:
    #  print 'rsync failed'
    try:
      f = urllib2.urlopen('http://%s/sea/%s.sql' % (server, db), timeout=10)
      print 'using urllib2 to grab %s.sql' % db
      local_file = open(fname, 'w')
      local_file.write(f.read())
      local_file.close()
    except:
      print 'No remote database is available.  Sticking with the local version.'
    try:
      os.system("mysql -u %s -p'%s' %s < %s" % (user, password, db, fname))
    except:
      print 'no local %s.sql file found--continuing with what is already in the database' % db

  def run(self):
    user = self.username
    password = self.password
    server = self.server
    db = self.db
    print 'downloading md5sum for %s...' % db
    print 'http://%s/sea/%s.md5sum' % (server, db)
    try:
      f = urllib2.urlopen('http://%s/sea/%s.md5sum' % (server, db))
      md5sum_remote = f.read().split()[0]

      home = os.environ['HOME']
      if not os.path.exists('%s/.phamerator' % home):
        print 'creating .phamerator directory...'
        os.mkdir('%s/.phamerator' % home)
      print 'dumping local %s database to a file...' % db
      # skip the local mysqldump, and just check to see if the local (previously downloaded)
      # dumpfile matches the one from the server
      if not os.path.exists('%s/.phamerator/%s.sql' % (home, db)):
        mysqldump_cmd = "mysqldump -u %s -p'%s' --skip-comments %s > %s/.phamerator/%s.sql" % (user, password, db, home, db)
        try:
          os.system(mysqldump_cmd)
        except:
          print 'error running %s' % mysqldump_cmd
      print 'dumping finished'

      if not os.path.exists('%s/.phamerator/%s.sql' % (home, db)):
        print 'local database %s could not be dumped.  Is the database server running?' % db
        sys.exit()

      import md5
      local = open('%s/.phamerator/%s.sql' % (home, db)).read()
      m = md5.new()
      m.update(local)
      md5sum_local = m.hexdigest()

      print md5sum_local, md5sum_remote
      if md5sum_local != md5sum_remote:
        print 'Local database is out of date...downloading...'
        self.updateDB(user, password, server, db)  #uncomment this when db problem is fixed!
      else: print 'local and remote databases are identical'
    except: 
      print "Unexpected error:", sys.exc_info()
      print "can't contact the server.  using local copy even though it might be out of date"
      pass
    self.evnt.set()
