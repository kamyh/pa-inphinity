#!/usr/bin/env python

import re

def replace_percent(filename):
  file = open(filename)
  content = file.read()
  re


def main():
  pass
